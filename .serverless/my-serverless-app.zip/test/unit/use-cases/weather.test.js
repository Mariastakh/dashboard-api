const weather = require("../../../lib/use-cases/Weather");

describe("weather", () => {
  xit("should get the location", async () => {
    const weatherUpdate = await weather();
    // testing an external service here
  });
});
