
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'astakhovam94',
  applicationName: 'dashboard',
  appUid: 'yXVmShPK2vLsp3Kshc',
  orgUid: 'Cm42ZHjW8F6QQsJ4W3',
  deploymentUid: '5afef148-3abf-477e-87db-b98a51059b1e',
  serviceName: 'dashboard',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'production',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.11',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'dashboard-production-app', timeout: 10 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}